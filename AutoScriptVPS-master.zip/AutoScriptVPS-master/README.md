
<h1 align="center">AutoScriptVPS<img src="https://img.shields.io/badge/Version-2.0-blue.svg"></h1>

<p align="center">AutoScriptVPS is made by _Dreyannz_ to minimize the time consumed and user involvement in setting up your VPS</p>
<h3 align="center">Supported Linux Distribution</h3>
<p align="center">
  <a><img src="https://img.shields.io/badge/Support-Debian%208-red.svg"></a>
  <a><img src="https://img.shields.io/badge/Support-Debian%209-red.svg"></a>
</p>
<h3 align="center">Services</h3>
<p align="center">
  <a><img src="https://img.shields.io/badge/Service-OpenSSH-green.svg"></a>
  <a><img src="https://img.shields.io/badge/Service-Dropbear-green.svg"></a>
  <a><img src="https://img.shields.io/badge/Service-Stunnel-green.svg"></a>
  <a><img src="https://img.shields.io/badge/Service-OpenVPN-green.svg"></a>
  <a><img src="https://img.shields.io/badge/Service-Squid3-green.svg"></a>
 </p>
<h3 align="center">Commands</h3>
<p align="center">
  <a><img src="https://img.shields.io/badge/Commands-menu-yellow.svg"></a>
  <a><img src="https://img.shields.io/badge/Commands-accounts-yellow.svg"></a>
  <a><img src="https://img.shields.io/badge/Commands-options-yellow.svg"></a>
  <a><img src="https://img.shields.io/badge/Commands-server-yellow.svg"></a>
 </p>

<h3 align="center">Installation</h3>

<p align="center">
wget -O AutoScriptVPS https://git.io/fA44X
  </p>
  <p align="center">
  chmod +x AutoScriptVPS
  </p>
  <p align="center">
  ./AutoScriptVPS
</p>

<h3 align="center">Screenshots</h3>
<p align="center">
<img src="https://github.com/Dreyannz/AutoScriptVPS/raw/master/Files/Screenshots/1.JPG">
   </p>
  <p align="center">
  <img src="https://github.com/Dreyannz/AutoScriptVPS/raw/master/Files/Screenshots/2.JPG">
   </p>
  <p align="center">
  <img src="https://github.com/Dreyannz/AutoScriptVPS/raw/master/Files/Screenshots/3.JPG">
  </p>
  <p align="center">
  <img src="https://github.com/Dreyannz/AutoScriptVPS/raw/master/Files/Screenshots/4.JPG">
   </p>
